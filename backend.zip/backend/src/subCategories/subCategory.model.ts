export interface SubCategory {
  id: number;
  name: string;
  categoryId: number;
}
